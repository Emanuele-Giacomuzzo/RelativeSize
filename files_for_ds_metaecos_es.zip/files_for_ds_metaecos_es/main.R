#Needs combination_sets_isolated_systems, ds_metaecosystems, calculate.hedges_d

source("/Users/Ema/Documents/Github/RelativeSize/files_for_ds_metaecos_es/calculate.hedges_d.R")
combination_sets_isolated_systems = read.csv(file = "/Users/Ema/Documents/Github/RelativeSize/files_for_ds_metaecos_es/combination_sets_isolated_systems.csv")
ds_metaecosystems = read.csv(file = "/Users/Ema/Documents/Github/RelativeSize/files_for_ds_metaecos_es/ds_metaecosystems.csv")

treatments_and_controls_metaecos = data.frame(
  treatment = c(
    "Small meta-ecosystem (s)",
    "Small-Medium meta-ecosystem (s)",
    "Medium-Large meta-ecosystem (s)",
    "Large meta-ecosystem (s)",
    "Small meta-ecosystem (s*d)",
    "Small-Medium meta-ecosystem (s*d)",
    "Medium-Large meta-ecosystem (s*d)",
    "Large meta-ecosystem (s*d)"
  ),
  control = c(
    "Small two-patch isolated (s)",
    "Small-Medium two-patch isolated (s)",
    "Medium-Large two-patch isolated (s)",
    "Large two-patch isolated (s)",
    "Small two-patch isolated (s*d)",
    "Small-Medium two-patch isolated (s*d)",
    "Medium-Large two-patch isolated (s*d)",
    "Large two-patch isolated (s*d)"
  )
)

columns_metaecos = c("time_point",
                     "day",
                     "system_nr",
                     "system_type",
                     "patch_size_ml",
                     "patches_combined")

variables_metaecos = "total_metaecosystem_bioarea_mm2"

time_points = 1 : 7

metaeco_type_count = 0
for (metaeco_type_i in "Small meta-ecosystem (s)"){ #treatments_and_controls_metaecos$treatment) {
  
  metaeco_type_count = metaeco_type_count + 1
  
  isolated_type_i = treatments_and_controls_metaecos %>%
    filter(treatment == metaeco_type_i) %>%
    pull(control)
  
  nr_of_sets = combination_sets_isolated_systems %>%
    filter(system_type == isolated_type_i) %>%
    pull(set) %>%
    max()
  
  for (set_i in 1 : nr_of_sets) {
    variable_count = 0
    for (variable_i in variables_metaecos) {
      variable_count = variable_count + 1
      for (time_point_i in time_points) {
        if(time_point_i == 0) next
        
        #Parameters
        columns_to_group_by = columns_metaecos[(columns_metaecos != "system_nr") & (columns_metaecos != "patches_combined")]
        
        system_nrs_of_set_i = combination_sets_isolated_systems %>%
          filter(system_type %in% isolated_type_i,
                 set == set_i) %>%
          pull(system_nr)
        
        new_dataset = ds_metaecosystems %>%
          filter(system_type == metaeco_type_i | system_nr %in% system_nrs_of_set_i,
                 time_point == time_point_i,
                 !is.na(!!sym(variable_i))) %>%
          group_by_at(all_of(columns_to_group_by)) %>%
          summarise(across(all_of(variable_i),
                           list(mean = mean,
                                sd = sd)),
                    sample_size = n()) %>%
          rename_with(~ paste0(variable_i, "_sample_size"),
                      matches("sample_size")) %>%
          mutate(!!paste0(variable_i, "_d") := NA,
                 !!paste0(variable_i, "_d_upper") := NA,
                 !!paste0(variable_i, "_d_lower") := NA)
        
        treatment_row = new_dataset %>%
          filter(system_type == metaeco_type_i)
        
        control_row = new_dataset %>%
          filter(system_type == isolated_type_i)
        
        hedges_d = calculate.hedges_d(
          treatment_row[[paste0(variable_i, "_mean")]],
          treatment_row[[paste0(variable_i, "_sd")]],
          treatment_row[[paste0(variable_i, "_sample_size")]],
          control_row[[paste0(variable_i, "_mean")]],
          control_row[[paste0(variable_i, "_sd")]],
          control_row[[paste0(variable_i, "_sample_size")]]
        )
        
        new_row = new_dataset %>%
          filter(system_type == metaeco_type_i) %>%
          mutate(!!paste0(variable_i, "_d") := hedges_d$d,
                 !!paste0(variable_i, "_d_upper") := hedges_d$upper_CI,
                 !!paste0(variable_i, "_d_lower") := hedges_d$lower_CI)
        
        if (!exists("ds_metaecos_es")) {ds_metaecos_es = new_row} else
        {ds_metaecos_es = rbind(ds_metaecos_es, new_row)}
        
      }
    }
  }
}

ds_metaecos_es %>%
  group_by_at(all_of(columns_to_group_by)) %>%
  summarise(total_metaecosystem_bioarea_mm2_d = mean(total_metaecosystem_bioarea_mm2_d),
            total_metaecosystem_bioarea_mm2_d_upper = mean(total_metaecosystem_bioarea_mm2_d_upper),
            total_metaecosystem_bioarea_mm2_d_lower = mean(total_metaecosystem_bioarea_mm2_d_lower))

write.csv(ds_metaecos_es,
          file = "/Users/Ema/Documents/Github/RelativeSize/files_for_ds_metaecos_es/ds_metaecos_es.csv")